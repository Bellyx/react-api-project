<?php
// กำหนดให้ทุกโดเมนสามารถเข้าถึง API นี้ได้
header("Access-Control-Allow-Origin: *");  // หรือให้ระบุโดเมนที่อนุญาตเท่านั้น เช่น "http://localhost:3000"
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");


header('Content-Type: application/json');

// เปิดการแสดงผลข้อผิดพลาด (เฉพาะตอนพัฒนา)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// รองรับ preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// เชื่อมต่อฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "comanysite");
$conn->set_charset("utf8");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'เชื่อมต่อฐานข้อมูลไม่สำเร็จ']);
    exit();
}

// ดึงข้อมูลจากตาราง contactpage (เปลี่ยนชื่อตารางตามที่คุณใช้จริง)
$sql = "SELECT * FROM contactpage WHERE Id = 1 LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode([
        'success' => true,
        'Phone' => $row['Phone'],
        'Email' => $row['Email'],
        'Address' => $row['Address'],
        'MapEmbedUrl' => $row['MapEmbedUrl'],
        'FacebookUrl' => $row['FacebookUrl'],
        'InstagramUrl' => $row['InstagramUrl'],
        'TwitterUrl' => $row['TwitterUrl'],
        'LinkedinUrl' => $row['LinkedinUrl'],
        'LastUpdated' => $row['LastUpdated']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'ไม่พบข้อมูล']);
}
$conn->close();

?>




