<?php
// เปิดการแสดงผลข้อผิดพลาด
ini_set('display_errors', 1);
error_reporting(E_ALL);

// เชื่อมต่อฐานข้อมูล
$host = "localhost";
$username = "root";
$password = "";
$dbname = "comanysite";  // เปลี่ยนให้เป็นชื่อฐานข้อมูลของคุณ

$conn = new mysqli($host, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

// ตรวจสอบว่าได้รับข้อมูลจาก Client หรือไม่
if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'ไม่ได้รับข้อมูลจาก Client']);
    exit();
}

// ตรวจสอบข้อมูล user และ password
if (!isset($data['user']) || !isset($data['password'])) {
    echo json_encode(['success' => false, 'message' => 'ข้อมูลไม่ครบถ้วน']);
    exit();
}

$user = $data['user'];
$password = $data['password'];

// ใช้ Prepared Statements เพื่อป้องกัน SQL Injection
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $user, $password);
$stmt->execute();
$result = $stmt->get_result();

// ตรวจสอบผลลัพธ์
if ($result->num_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'ล็อกอินสำเร็จ']);
} else {
    echo json_encode(['success' => false, 'message' => 'อีเมลหรือรหัสผ่านไม่ถูกต้อง']);
}

$stmt->close();
$conn->close();
?>
