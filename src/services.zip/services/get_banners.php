<?php
header("Content-Type: application/json");
require_once('../db.php');

$stmt = $pdo->query("SELECT * FROM banners ORDER BY created_at DESC");
$banners = $stmt->fetchAll();

echo json_encode($banners);
?>