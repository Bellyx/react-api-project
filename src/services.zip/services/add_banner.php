<?php
header("Content-Type: application/json");
require_once('../db.php');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['image_url'])) {
  http_response_code(400);
  echo json_encode(["error" => "image_url is required"]);
  exit;
}

$caption = $data['caption'] ?? null;

$stmt = $pdo->prepare("INSERT INTO banners (image_url, caption) VALUES (?, ?)");
$stmt->execute([$data['image_url'], $caption]);

echo json_encode(["message" => "Banner added successfully"]);
?>
